package com.example.myapplication.presenter;

public interface IPHome2 {
    void LoadData();
}
