package com.example.myapplication.view;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.model.data_map;
import com.example.myapplication.presenter.IPHome2;
import com.example.myapplication.presenter.PHome2;
import com.example.myapplication.util.putdata;

import java.util.ArrayList;
import java.util.List;

public class Home2 extends Fragment implements IHome2  {
    putdata pd;
    RecyclerView list;
    LinearLayoutManager mLayoutManager;

    IPHome2 ipHome2;
    EditText key;
    ImageButton back, search;
    adapter_map adapter;
    RelativeLayout show, showk;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_home,null);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        anhxa(view);
//        pd = new putdata(getContext());
        ipHome2 = new PHome2(this,getContext());
        ipHome2.LoadData();
    }
    private void anhxa(View view ){
        list = (RecyclerView) view.findViewById(R.id.list_item);
    }
    @Override
    public void LoadData(List<data_map> data,adapter_map adapter) {
        mLayoutManager = new LinearLayoutManager(getContext());

        list.setAdapter(adapter);
        list.setLayoutManager(mLayoutManager);
    }

    @Override
    public void LoadSuccess(String text,Context context) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void LoadError(String text,Context context) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
    }
}
