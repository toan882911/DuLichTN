package com.example.myapplication.view;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
public class Detail extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);
        ImageView img=(ImageView) findViewById(R.id.img);
        TextView text=(TextView) findViewById(R.id.noidung);
        CollapsingToolbarLayout coll = (CollapsingToolbarLayout) findViewById(R.id.collapsingToolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        ImageButton imgbtn=(ImageButton) findViewById(R.id.back);
        Intent intent = getIntent();
        String nd = intent.getStringExtra("noidung");
        String tit = intent.getStringExtra("tit");
        String image = intent.getStringExtra("img");
        coll.setTitle(tit);
        text.setText(nd);
        int resID=this.getResources().getIdentifier(image,"drawable",this.getPackageName());
        img.setImageResource(resID);
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(Detail.this, MainActivity.class);
                startActivity(intent1);
            }
        });
    }
//    private boolean isNetworkConnected(Context context) {
//        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//
//        return cm.getActiveNetworkInfo() != null;
//    }
}
