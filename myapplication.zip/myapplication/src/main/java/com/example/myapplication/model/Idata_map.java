package com.example.myapplication.model;

public interface Idata_map {
    String getName();
    String getNoiDung();
    String getImg();
    Double getX();
    Double getY();
}
